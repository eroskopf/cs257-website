# Team B - Contract
## Goals
- Learn technical side of data collection/creating/displaying a website, and maybe a bit of GUI
- Create a project that communicates information effectively
- Learn how to work cohesively as a team
- Submit deliverables that satisfy all three of us 
## Strengths
### Adrian:
- Good at following directions
- Good at working in a group and building consensus
- Good at reviewing code/debugging
- Good at getting work done in time
- Good at formatting
### Emma:
- Good leader
- Experienced, can help the group with knowledge
- Good at teamwork, helping, and collaboration
- We follow Emma until the end
- Forever and ever
- Has blue hair
- Technically knowledgeable
### Brian:
- Thinking critically about and visualizing project plans
- Good at working with others when in person
- Forward planning!
- Good at boosting team morale
- Conflict resolution
- Good googler

## Capitalizing on Strengths
### Adrian:
- I have worked on many CS projects before and have also put together several websites, which can be useful to the overall group effort
- I work well with others and can fill in to work as needed, if anything needs to be done I can do it
- I’m good at proofreading/debugging, and testing everything out to make sure it works as intended
- I can make our final product look good
### Emma:
- I have experience using GitHub and the command line so in the beginning since I am the most experienced member I will try to help my group mates and take more of these types of tasks
- I also am good at finding guides so if we’re trying to find a guide on how to do a specific part of the project, I can definitely help out
- I like working with other people so I will try to stay in communication with everyone 
### Brian
- I am inexperienced with making CS projects, but I’ll listen closely to my teammates where I need to and learn the rest from Google and in class
- I think I will contribute the most to the team when we are laying out the roadmap for how we want to progress with our project
- I will spend as much time learning different technical aspects as I need to outside of group meetings
- I will be flexible in how I assist my teammates
## Rules
- For every long term (>2 weeks) assignment, meet at least 3 times throughout the 2 weeks. 
- Standing meeting on Mondays at 8 or 9 so that we are all on the same page, until we feel like we’ve finished the work we need to get done or have assigned roles 
- Each person comes with items they think need to get done and we are all responsible for making sure everything is addressed during the meeting
- Group chat with phone numbers, not everyone has/wants Slack notifications turned on
- If someone feels like the group discourse is not respectful we would expect that member to express what I making them feel that way in a polite manner and we will work to fix the way we communicate with each other to reflect our mutual respect for one another
- If someone goes radio silent we will try to check in with them because we expect all group members to check in at each class period at least and outside of class when we are meeting
- We will use Google Drive, Slack, and texting, as well as email if necessary
- For decisions, we will discuss different options as a group to find consensus, but if that is not possible we will do a majority vote
- We will attempt to play to everyone’s strengths so that everyone can do something that they feel comfortable with and so that the team member’s workload is approximately even. If this isn’t possible to make it even, we might just work together so it doesn’t get too uneven 
- Decide on team assignments as a group, and we expect everyone to complete their assignment in a timely manner, if they can’t we expect them to communicate this with the group so we can work it out. We expect each team member to put in the amount of work that will result in an acceptable deliverable
- We will contact Amy if a group member is not pulling their weight, after we have a conversation with said group member on why they are not doing the agreed upon work 
- We will attempt to solve conflict by discussion and unanimous decisions, but if that is not possible we will revert to majority decision 
