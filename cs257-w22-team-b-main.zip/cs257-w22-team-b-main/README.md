# Plan
- Our plan to to use Steam player data to create a website to display details on popular games and user trends from 2012-2021
- We will be using the public data from Steam, compiled into a dataset on Kaggle

## Subsections
- **gitlab** is a folder that contains all of our practice files that we created to get used to github
- **project_proposal** contains our team contract, our project proposal, and other similar documents
- **web** contains the files to build the front end of our website 

## Revisions
### Project Proposal Revision
- Edited project_proposal.md for project proposal team deliverable. Edited on February 14th.
- Turned in metadata worksheet (forgot to turn it in last time!). Edited on February 14th.
### Backend Revision
- Edited the comments in datasource.py based on grader advice
- Edited the \_to\_datetime method to make the dates more clear
