user = 'roskopfe'
database = 'roskopfe'
password = 'heart585summer'